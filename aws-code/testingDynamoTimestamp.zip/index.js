var AWS = require("aws-sdk");
var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
    
    var brand;
    var tableName;

    console.log("BEGIN: getQuestionnaireConfig");
    console.log('Received event:', JSON.stringify(event, null, 2));
    console.log('Received context:', JSON.stringify(context, null, 2));


    tableName = "Gifting";
    brand = "align";

    var params = {
        TableName: tableName,
        Key: {
            brand: brand
        },
        UpdateExpression: "set site = :s",
        ExpressionAttributeValues:{
            ":s":"NFEG",
        }
    };
    console.log("params: " + JSON.stringify(params));
    
    docClient.update(params, function(err, data) {
        if (err) {
            console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
        } else {
            console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
        }
    });
}
;
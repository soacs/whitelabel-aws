var AWS = require("aws-sdk");
var themeListTableName = 'ThemeList';
var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
    // TODO implement

    console.log('Loading getThemeList function');

    var themeListData;
    var response;
    var queryStringParameters;
    var httpMethod;
    var responseBody;

    console.log("BEGIN: getThemeList");
    console.log('Received event:', JSON.stringify(event, null, 2));
    console.log('Received context:', JSON.stringify(context, null, 2));

    httpMethod = event.httpMethod;
    console.log('httpMethod: ', httpMethod);

    var params = {
        TableName: themeListTableName,
    };
    console.log("params: " + JSON.stringify(params));
    var dbResponse = docClient.scan(params, function(err, data) {
        console.log("inside callback");
        if (err) {
            context.fail("Error in scan " + err);
        }
        else {
            console.log("data: " + JSON.stringify(data));
            if (data !== undefined) {
                themeListData = data.Items;
                console.log("themeListData: " + JSON.stringify(themeListData));
                
                if (httpMethod === "GET") {
                    responseBody = JSON.stringify(themeListData);
                } else {
                     responseBody = themeListData;
                }
    
                const response = {
                    statusCode: 200,
                     headers: {
                                 "Access-Control-Allow-Origin" : "*",
                                 "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token;ao-token","Content-Type":"application/json",
                                 "Access-Control-Allow-Methods" : "GET,POST,OPTIONS",

        },
                    body: responseBody
                };
                callback(null, response);
                console.log("END: getThemeList");
            }
        }

    });
}

// var http = require('http');

exports.handler = async (event) => {
    // TODO implement
    console.log('EVENT:' + event);
/*       console.log('Testing KEYCLOAK CALL');
    var username = event.username;
    var password = event.password;
    console.log('username: ', event.username);
    console.log('password: ', req.body.password);
    const postedData = 'grant_type=' + 'password' + '&username=' + username + '&password=' + password + '&client_id=' + 'dwp';

    console.log('postedData = ', postedData);

    var options = {
        hostname: '10.70.46.11',
        port: 8080,
        path: '/auth/realms/whitelabel/protocol/openid-connect/token',
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
        }
    };
    var req = http.request(options, function (res) {
        console.log(`statusCode: ${res.statusCode}`);
        console.log('Headers: ' + JSON.stringify(res.headers));
        res.setEncoding('utf8');
        res.on('data', function (body) {
            //console.log(Object.getOwnPropertyNames(body));
            //var keys = Object.keys(body);
           // console.log('keys: ' + keys);
            // var myBody = Object.assign({}, body);
            var { access_token , ...theRest } = body;
            console.log('access_token: ' + access_token);
           // var jwtToken = body;
          //  session.jwtToken = body.access_token;
          //  console.log('session.jwtToken.access_token: ' + session.jwtToken.access_token);
           // console.log(body);

        });
    });
    req.on('error', function (e) {
        console.log('problem with request: ' + e.message);
    });
    // write data to request body
    req.write(postedData);
    req.end();
    */
    
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
